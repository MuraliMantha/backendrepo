const express = require('express');
const app = express();
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jwt-simple');
const uuid = require('uuid');

const cors = require('cors');

app.use(cors());
app.use(bodyParser.json());

const SECRET = 'krishna'; // For JWT encryption

// Database setup
const db = new sqlite3.Database('./todos.db', (err) => {
    if (err) {
        console.error('Error opening database', err);
    } else {
        db.run(`
            CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY,
                name TEXT,
                email TEXT UNIQUE,
                password TEXT
            );
            
        `);
        db.run(`
            CREATE TABLE IF NOT EXISTS tasks (
                id TEXT PRIMARY KEY,
                user_id TEXT,
                title TEXT,
                status TEXT,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
        `)
    }
});

// User Authentication routes (signup, login, token validation)
app.post('/signup', async (req, res) => {
    const { name, email, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const id = uuid.v4();
    db.run(`INSERT INTO users (id, name, email, password) VALUES (?, ?, ?, ?)`, 
           [id, name, email, hashedPassword], 
           (err) => {
        if (err) return res.status(400).json({ error: err.message });
        res.status(201).json({ message: 'User registered' });
    });
});

app.post('/login', (req, res) => {
    const { email, password } = req.body;
    db.get(`SELECT * FROM users WHERE email = ?`, [email], async (err, user) => {
        if (err || !user) return res.status(400).json({ error: 'Invalid credentials' });
        const valid = await bcrypt.compare(password, user.password);
        if (!valid) return res.status(400).json({ error: 'Invalid credentials' });

        const token = jwt.encode({ id: user.id }, SECRET);
        res.json({ token });
    });
});

// Middleware to check JWT
const requireAuth = (req, res, next) => {
    const token = req.headers['authorization'];
    if (!token) return res.status(403).json({ message: 'Token missing' });

    try {
        const decoded = jwt.decode(token, SECRET);
        req.userId = decoded.id;
        next();
    } catch (err) {
        res.status(401).json({ message: 'Invalid token' });
    }
};

// Task Management routes (CRUD)
app.post('/tasks', requireAuth, (req, res) => {
    const { title, status } = req.body;
    const id = uuid.v4();
    db.run(`INSERT INTO tasks (id, user_id, title, status) VALUES (?, ?, ?, ?)`,
           [id, req.userId, title, status || 'pending'], 
           (err) => {
        if (err) {
            console.log(err)
           return res.status(400).json({ error: err.message });
        } 
        res.status(201).json({ message: 'Task created' });
    });
});

app.get('/tasks', requireAuth, (req, res) => {
    db.all(`SELECT * FROM tasks WHERE user_id = ?`, [req.userId], (err, tasks) => {
        if (err) return res.status(400).json({ error: err.message });
        res.json(tasks);
    });
});

app.put('/tasks/:id', requireAuth, (req, res) => {
    const { title, status } = req.body;
    db.run(`UPDATE tasks SET title = ?, status = ? WHERE id = ? AND user_id = ?`, 
           [title, status, req.params.id, req.userId], 
           (err) => {
        if (err) return res.status(400).json({ error: err.message });
        res.json({ message: 'Task updated' });
    });
});

app.delete('/tasks/:id', requireAuth, (req, res) => {
    db.run(`DELETE FROM tasks WHERE id = ? AND user_id = ?`, [req.params.id, req.userId], (err) => {
        if (err) return res.status(400).json({ error: err.message });
        res.json({ message: 'Task deleted' });
    });
});

// Profile Management routes (CRUD)
app.get('/profile', requireAuth, (req, res) => {
    db.get(`SELECT name, email FROM users WHERE id = ?`, [req.userId], (err, user) => {
        if (err) return res.status(400).json({ error: err.message });
        res.json(user);
    });
});

app.put('/profile', requireAuth, (req, res) => {
    const { name, email, password } = req.body;
    db.run(`UPDATE users SET name = ?, email = ?, password = ? WHERE id = ?`,
           [name, email, password ? bcrypt.hashSync(password, 10) : undefined, req.userId],
           (err) => {
        if (err) return res.status(400).json({ error: err.message });
        res.json({ message: 'Profile updated' });
    });
});

// Start server
app.listen(8000, () => console.log('Server running on port 8000'));
